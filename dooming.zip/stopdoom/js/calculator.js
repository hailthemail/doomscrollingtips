// calculator.js

const alternatives = [
  { title: '📖 Прочитать книгу', desc: 'За 3 часа можно прочитать 50-70 страниц' },
  { title: '🏃 Спорт', desc: 'Тренировка, пробежка, йога' },
  { title: '🎨 Творчество', desc: 'Рисование, музыка, письмо' },
  { title: '👥 Встреча с друзьями', desc: 'Живое общение вместо онлайн' },
  { title: '🎬 Фильм', desc: 'Посмотри хороший фильм осознанно' },
  { title: '🍳 Готовка', desc: 'Приготовь новое блюдо' },
  { title: '🧹 Уборка', desc: 'Наведи порядок в комнате' },
  { title: '📝 Дневник', desc: 'Запиши мысли и планы' },
  { title: '🎮 Хобби', desc: 'Займись любимым делом' },
  { title: '😴 Сон', desc: 'Выспись как следует' }
];

document.getElementById('calc-form').addEventListener('submit', e => {
  e.preventDefault();
  const hours = parseFloat(document.getElementById('daily-hours').value);
  const age = parseInt(document.getElementById('age').value);
  
  if (!hours || !age || hours < 0 || hours > 24 || age < 10 || age > 100) {
    alert('Введи корректные данные!');
    return;
  }
  
  const daysPerYear = (hours * 365) / 24;
  const hoursPerYear = hours * 365;
  const yearsUntil80 = 80 - age;
  const totalYears = (hours * 365 * yearsUntil80) / (24 * 365);
  
  document.getElementById('days-per-year').textContent = daysPerYear.toFixed(1);
  document.getElementById('hours-per-year').textContent = hoursPerYear.toLocaleString();
  document.getElementById('total-years').textContent = totalYears.toFixed(1);
  
  const altsContainer = document.getElementById('alternatives-list');
  altsContainer.innerHTML = alternatives.slice(0, 6).map(a => `<div class="alternative-item"><h4>${a.title}</h4><p>${a.desc}</p></div>`).join('');
  
  document.getElementById('motivation-text').textContent = `За ${totalYears.toFixed(1)} лет можно: выучить 3-5 языков, прочитать 500+ книг, пробежать 10+ марафонов, освоить 5+ профессий. Ты выбираешь, на что потратить жизнь!`;
  
  document.getElementById('calc-result').style.display = 'block';
});