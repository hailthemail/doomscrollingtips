// Визуальные эффекты StopDoom

function initScrollProgress() {
  const progress = document.createElement('div');
  progress.className = 'scroll-progress';
  document.body.appendChild(progress);

  function updateProgress() {
    const scrollTop = window.scrollY;
    const pageHeight =
      document.documentElement.scrollHeight - window.innerHeight;

    const percent =
      pageHeight > 0 ? (scrollTop / pageHeight) * 100 : 0;

    progress.style.width = `${percent}%`;
  }

  window.addEventListener('scroll', updateProgress, {
    passive: true
  });

  updateProgress();
}

function initRevealAnimations() {
  const selectors = [
    '.feature-card',
    '.stat-card',
    '.technique-card',
    '.alt-card',
    '.faq-item',
    '.about-card',
    '.help-card',
    '.result-card',
    '.cta-box'
  ];

  const elements = document.querySelectorAll(selectors.join(', '));

  elements.forEach((element, index) => {
    element.classList.add('reveal');
    element.style.transitionDelay = `${(index % 5) * 70}ms`;
  });

  if (!('IntersectionObserver' in window)) {
    elements.forEach(element => {
      element.classList.add('visible');
    });

    return;
  }

  const observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.12
    }
  );

  elements.forEach(element => {
    observer.observe(element);
  });
}

function initLogoEffect() {
  const logo = document.querySelector('.logo');

  if (!logo) return;

  logo.addEventListener('mouseenter', () => {
    logo.style.transform = 'rotate(-2deg) scale(1.05)';
  });

  logo.addEventListener('mouseleave', () => {
    logo.style.transform = '';
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initScrollProgress();
  initRevealAnimations();
  initLogoEffect();
});