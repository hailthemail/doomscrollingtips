function startConfetti() {
  const colors = [
    '#6366f1',
    '#8b5cf6',
    '#f43f5e',
    '#22d3ee',
    '#facc15'
  ];

  for (let i = 0; i < 80; i++) {
    const piece = document.createElement('span');

    piece.style.position = 'fixed';
    piece.style.left = `${Math.random() * 100}vw`;
    piece.style.top = '-20px';
    piece.style.width = '8px';
    piece.style.height = '14px';
    piece.style.background =
      colors[Math.floor(Math.random() * colors.length)];
    piece.style.transform =
      `rotate(${Math.random() * 360}deg)`;
    piece.style.zIndex = '3000';
    piece.style.pointerEvents = 'none';
    piece.style.borderRadius = '2px';

    document.body.appendChild(piece);

    const duration = 1800 + Math.random() * 1800;
    const x = (Math.random() - 0.5) * 300;

    piece.animate(
      [
        {
          transform: 'translate(0, 0) rotate(0deg)',
          opacity: 1
        },
        {
          transform:
            `translate(${x}px, 110vh) rotate(720deg)`,
          opacity: 0
        }
      ],
      {
        duration,
        easing: 'cubic-bezier(.2,.8,.3,1)'
      }
    );

    setTimeout(() => {
      piece.remove();
    }, duration);
  }
}