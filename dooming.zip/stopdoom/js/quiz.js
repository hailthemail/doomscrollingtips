// quiz.js — ИСПРАВЛЕННЫЙ
const questions = [
  { id: 1, text: 'Как часто ты читаешь негативные новости в соцсетях?', options: [{text: 'Каждый день', value: 4}, {text: 'Несколько раз в неделю', value: 3}, {text: 'Несколько раз в месяц', value: 2}, {text: 'Редко', value: 1}] },
  { id: 2, text: 'Трудно остановиться, даже понимаешь вред?', options: [{text: 'Да, часто', value: 4}, {text: 'Иногда', value: 3}, {text: 'Редко', value: 2}, {text: 'Нет', value: 1}] },
  { id: 3, text: 'Сколько времени в день в соцсетях?', options: [{text: 'Более 4 часов', value: 4}, {text: '2-4 часа', value: 3}, {text: '1-2 часа', value: 2}, {text: 'Менее 1 часа', value: 1}] },
  { id: 4, text: 'Меняется ли настроение после чтения?', options: [{text: 'Ухудшается', value: 4}, {text: 'Немного ухудшается', value: 3}, {text: 'Не меняется', value: 2}, {text: 'Улучшается', value: 1}] },
  { id: 5, text: 'Проверяешь телефон сразу после пробуждения?', options: [{text: 'Да, сразу', value: 4}, {text: 'В течение 30 мин', value: 3}, {text: 'Иногда', value: 2}, {text: 'Нет', value: 1}] },
  { id: 6, text: 'Скроллишь перед сном?', options: [{text: 'Более 1 часа', value: 4}, {text: '30-60 мин', value: 3}, {text: 'Менее 30 мин', value: 2}, {text: 'Нет', value: 1}] },
  { id: 7, text: 'Трудности с засыпанием из-за прочитанного?', options: [{text: 'Часто', value: 4}, {text: 'Иногда', value: 3}, {text: 'Редко', value: 2}, {text: 'Никогда', value: 1}] },
  { id: 8, text: 'Чувствуешь тревогу после новостей?', options: [{text: 'Да, часто', value: 4}, {text: 'Иногда', value: 3}, {text: 'Редко', value: 2}, {text: 'Нет', value: 1}] },
  { id: 9, text: 'Механически скроллишь без цели?', options: [{text: 'Очень часто', value: 4}, {text: 'Несколько раз в неделю', value: 3}, {text: 'Несколько раз в месяц', value: 2}, {text: 'Редко', value: 1}] },
  { id: 10, text: 'Усталость после использования соцсетей?', options: [{text: 'Да, часто', value: 4}, {text: 'Иногда', value: 3}, {text: 'Редко', value: 2}, {text: 'Нет', value: 1}] },
  { id: 11, text: 'Боешься упустить важное (FOMO)?', options: [{text: 'Да, очень', value: 4}, {text: 'Иногда', value: 3}, {text: 'Редко', value: 2}, {text: 'Нет', value: 1}] },
  { id: 12, text: 'Качество сна (1-10)?', options: [{text: '1-3', value: 4}, {text: '4-6', value: 3}, {text: '7-8', value: 2}, {text: '9-10', value: 1}] },
  { id: 13, text: 'Просыпаешься и проверяешь телефон?', options: [{text: 'Часто', value: 4}, {text: 'Иногда', value: 3}, {text: 'Редко', value: 2}, {text: 'Никогда', value: 1}] },
  { id: 14, text: 'Пытался сократить время, но не вышло?', options: [{text: 'Да, много раз', value: 4}, {text: 'Иногда получается', value: 3}, {text: 'Легко получилось', value: 2}, {text: 'Не пытался', value: 1}] },
  { id: 15, text: 'Чувствуешь беспомощность от новостей?', options: [{text: 'Да, часто', value: 4}, {text: 'Иногда', value: 3}, {text: 'Редко', value: 2}, {text: 'Нет', value: 1}] }
];

let currentQuestion = 0;
let answers = new Array(15).fill(null);

function renderQuestions() {
  const container = document.getElementById('quiz-questions');
  if (!container) return;

  container.innerHTML = '';

  questions.forEach((q, i) => {
    const block = document.createElement('div');
    block.className = 'question-block' + (i === 0 ? ' active' : '');

    let optionsHTML = '';
    q.options.forEach((o, j) => {
      const checked = answers[i] === o.value ? ' checked' : '';
      optionsHTML += '<li class="option-item"><label class="option-label"><input type="radio" name="q' + i + '" value="' + o.value + '"' + checked + '><span>' + o.text + '</span></label></li>';
    });

    block.innerHTML = '<h3 class="question-text">' + (i+1) + '. ' + q.text + '</h3><ul class="options-list">' + optionsHTML + '</ul>';
    container.appendChild(block);

    const inputs = block.querySelectorAll('input');
    inputs.forEach(inp => {
      inp.addEventListener('change', function() {
        answers[i] = parseInt(this.value);
      });
    });
  });

  updateNav();
}

function updateNav() {
  const prevBtn = document.getElementById('prev-btn');
  const nextBtn = document.getElementById('next-btn');
  const submitBtn = document.getElementById('submit-btn');
  const progress = document.getElementById('progress');
  const currentQ = document.getElementById('current-question');

  if (!prevBtn || !nextBtn || !submitBtn || !progress || !currentQ) return;

  prevBtn.disabled = currentQuestion === 0;

  if (currentQuestion === 14) {
    nextBtn.style.display = 'none';
    submitBtn.style.display = 'inline-block';
  } else {
    nextBtn.style.display = 'inline-block';
    submitBtn.style.display = 'none';
  }

  progress.style.width = ((currentQuestion + 1) / 15 * 100) + '%';
  currentQ.textContent = currentQuestion + 1;
}

function showQuestion(i) {
  const blocks = document.querySelectorAll('.question-block');
  blocks.forEach((b, idx) => {
    if (idx === i) {
      b.classList.add('active');
    } else {
      b.classList.remove('active');
    }
  });
  updateNav();
}

function calcResult() {
  const score = answers.reduce((s, a) => s + a, 0);
  let title, desc, recs;

  if (score <= 20) {
    title = 'Низкий риск';
    desc = 'У тебя здоровые привычки!';
    recs = '<h3>Продолжай:</h3><ul><li>Поддерживай границы</li><li>Периодически проверяй уровень</li></ul>';
  } else if (score <= 40) {
    title = 'Умеренный риск';
    desc = 'Есть признаки думскроллинга.';
    recs = '<h3>Что делать:</h3><ul><li>Начни трекер</li><li>Установи лимиты</li><li>Изучи техники</li></ul>';
  } else {
    title = 'Высокий риск';
    desc = 'Выраженный думскроллинг.';
    recs = '<h3>План:</h3><ul><li>Трекер сегодня</li><li>Удали приложения</li><li>Техники каждый день</li></ul>';
  }

  return { score, title, desc, recs };
}

function showResult() {
  const quizForm = document.getElementById('quiz-form');
  const quizResult = document.getElementById('quiz-result');

  if (!quizForm || !quizResult) return;

  const resultData = calcResult();

  quizForm.style.display = 'none';
  quizResult.style.display = 'block';

  document.getElementById('result-title').textContent = resultData.title;
  document.getElementById('score-number').textContent = resultData.score;
  document.getElementById('result-description').textContent = resultData.desc;
  document.getElementById('result-recommendations').innerHTML = resultData.recs;

  localStorage.setItem('doomscrollingScore', resultData.score.toString());
}

document.addEventListener('DOMContentLoaded', function() {
  renderQuestions();

  const prevBtn = document.getElementById('prev-btn');
  const nextBtn = document.getElementById('next-btn');
  const quizForm = document.getElementById('quiz-form');

  if (prevBtn) {
    prevBtn.addEventListener('click', function() {
      if (currentQuestion > 0) {
        currentQuestion--;
        showQuestion(currentQuestion);
      }
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener('click', function() {
      if (answers[currentQuestion] === null) {
        alert('Выбери ответ!');
        return;
      }
      if (currentQuestion < 14) {
        currentQuestion++;
        showQuestion(currentQuestion);
      }
    });
  }

  if (quizForm) {
    quizForm.addEventListener('submit', function(e) {
      e.preventDefault();
      if (answers[currentQuestion] === null) {
        alert('Выбери ответ!');
        return;
      }
      showResult();
    });
  }
});
