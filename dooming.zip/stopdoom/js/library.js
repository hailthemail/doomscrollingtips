// library.js

const techniques = [
  { id: 1, title: 'Цифровой детокс', category: 'behavioral', time: 60, difficulty: 'medium', desc: 'Полный отказ от устройств на определённое время.', steps: ['Выбери время (выходные/вечер)', 'Предупреди близких', 'Убери телефон в другое место', 'Займись офлайн-делами'] },
  { id: 2, title: 'Правило 20-20-20', category: 'cognitive', time: 5, difficulty: 'easy', desc: 'Каждые 20 минут смотри на 20 футов (6м) в течение 20 секунд.', steps: ['Поставь таймер на 20 мин', 'Когда зазвонит — отложи телефон', 'Посмотри вдаль 20 секунд', 'Продолжай'] },
  { id: 3, title: 'Осознанное дыхание', category: 'mindfulness', time: 5, difficulty: 'easy', desc: 'Дыхательная техника для снижения тревоги.', steps: ['Сядь удобно', 'Вдох 4 сек', 'Задержи 4 сек', 'Выдох 6 сек', 'Повтори 10 раз'] },
  { id: 4, title: 'Лимиты приложений', category: 'technical', time: 15, difficulty: 'easy', desc: 'Установи лимиты времени для соцсетей.', steps: ['Настройки → Экранное время', 'Лимиты приложений', 'Выбери соцсети', 'Установи 30-60 мин/день'] },
  { id: 5, title: 'Уведомления OFF', category: 'technical', time: 15, difficulty: 'easy', desc: 'Отключи все ненужные уведомления.', steps: ['Настройки → Уведомления', 'Отключи для соцсетей', 'Оставь только важные', 'Проверь через неделю'] },
  { id: 6, title: 'Техника Pomodoro', category: 'behavioral', time: 30, difficulty: 'medium', desc: '25 минут работы, 5 минут отдыха.', steps: ['Поставь таймер на 25 мин', 'Работай без телефона', '5 мин отдых', 'Повтори 4 раза', 'Длинный перерыв 15-30 мин'] },
  { id: 7, title: 'Ведение дневника', category: 'cognitive', time: 15, difficulty: 'easy', desc: 'Записывай триггеры и эмоции.', steps: ['Купи блокнот', 'Записывай когда тянешься к телефону', 'Что чувствовал?', 'Что можно было сделать?', 'Анализируй неделю'] },
  { id: 8, title: 'Зарядка вне спальни', category: 'technical', time: 30, difficulty: 'medium', desc: 'Заряжай телефон не в спальне.', steps: ['Купи длинный кабель', 'Заряжай в коридоре/кухне', 'Купи будильник', 'Не бери телефон в кровать'] },
  { id: 9, title: 'Медитация', category: 'mindfulness', time: 15, difficulty: 'medium', desc: 'Практика осознанности.', steps: ['Сядь удобно', 'Закрой глаза', 'Следи за дыханием', '10-15 минут', 'Каждый день'] },
  { id: 10, title: 'Серый экран', category: 'technical', time: 5, difficulty: 'easy', desc: 'Сделай экран чёрно-белым.', steps: ['Настройки → Универсальный доступ', 'Дисплей → Фильтры', 'Включи оттенки серого', 'Проверь через неделю'] },
  { id: 11, title: 'Информационная диета', category: 'cognitive', time: 30, difficulty: 'medium', desc: 'Ограничь источники новостей.', steps: ['Выбери 1-2 источника', 'Читай 1 раз в день', 'Не перед сном', 'Отпишись от токсичных'] },
  { id: 12, title: 'Физическая активность', category: 'behavioral', time: 30, difficulty: 'medium', desc: 'Замени скроллинг спортом.', steps: ['Выбери активность', '30 мин в день', 'Без телефона', 'Наслаждайся процессом'] },
  { id: 13, title: 'Социальные обязательства', category: 'behavioral', time: 60, difficulty: 'hard', desc: 'Встречайся с друзьями вживую.', steps: ['Позвони другу', 'Договорись о встрече', 'Встретьтесь без телефонов', 'Общайтесь 1-2 часа'] },
  { id: 14, title: 'Визуализация', category: 'mindfulness', time: 10, difficulty: 'easy', desc: 'Представь жизнь без думскроллинга.', steps: ['Закрой глаза', 'Представь идеальный день', 'Что ты делаешь?', 'Как себя чувствуешь?', 'Запиши'] },
  { id: 15, title: 'Приложения-блокеры', category: 'technical', time: 15, difficulty: 'easy', desc: 'Forest, Freedom, StayFocusd.', steps: ['Скачай Forest', 'Поставь таймер', 'Растёт дерево пока не трогаешь', 'Собирай достижения'] },
  { id: 16, title: 'Ритуал перед сном', category: 'mindfulness', time: 30, difficulty: 'medium', desc: 'Без телефона за 1 час до сна.', steps: ['За час до сна — телефон в сторону', 'Почитай книгу', 'Прими душ', 'Помедитируй', 'Ложись спать'] },
  { id: 17, title: 'Подписка на полезное', category: 'cognitive', time: 15, difficulty: 'easy', desc: 'Отпишись от негатива, подпишись на полезное.', steps: ['Пройдись по подпискам', 'Отпишись от токсичных', 'Подпишись на образовательные', 'Проверяй раз в месяц'] },
  { id: 18, title: 'Награда за успех', category: 'behavioral', time: 60, difficulty: 'medium', desc: 'Награждай себя за дни без думскроллинга.', steps: ['Поставь цель (7 дней)', 'Выбери награду', 'Отмечай прогресс', 'Получи награду'] },
  { id: 19, title: 'Группа поддержки', category: 'behavioral', time: 60, difficulty: 'hard', desc: 'Найди единомышленников.', steps: ['Расскажи друзьям о цели', 'Найди группу онлайн', 'Делись прогрессом', 'Поддерживай других'] },
  { id: 20, title: 'Профессиональная помощь', category: 'cognitive', time: 60, difficulty: 'hard', desc: 'Обратись к психологу.', steps: ['Найди специалиста', 'Запишись на приём', 'Расскажи о проблеме', 'Следуй рекомендациям'] }
];

function renderTechniques() {
  const cat = document.getElementById('category-filter').value;
  const time = document.getElementById('time-filter').value;
  const diff = document.getElementById('difficulty-filter').value;
  
  const filtered = techniques.filter(t => {
    if (cat !== 'all' && t.category !== cat) return false;
    if (time !== 'all' && t.time > parseInt(time)) return false;
    if (diff !== 'all' && t.difficulty !== diff) return false;
    return true;
  });
  
  const container = document.getElementById('techniques-grid');
  if (filtered.length === 0) {
    container.style.display = 'none';
    document.getElementById('no-results').style.display = 'block';
    return;
  }
  
  container.style.display = 'grid';
  document.getElementById('no-results').style.display = 'none';
  
  container.innerHTML = filtered.map(t => `
    <div class="technique-card">
      <div class="technique-header">
        <h3 class="technique-title">${t.title}</h3>
        <p>⏱️ ${t.time} мин | ${t.difficulty === 'easy' ? 'Лёгко' : t.difficulty === 'medium' ? 'Средне' : 'Сложно'}</p>
      </div>
      <div class="technique-body">
        <p class="technique-description">${t.desc}</p>
        <div class="technique-steps"><strong>Шаги:</strong><ol>${t.steps.map(s => `<li>${s}</li>`).join('')}</ol></div>
      </div>
    </div>
  `).join('');
}

document.getElementById('category-filter').addEventListener('change', renderTechniques);
document.getElementById('time-filter').addEventListener('change', renderTechniques);
document.getElementById('difficulty-filter').addEventListener('change', renderTechniques);
document.getElementById('reset-filters').addEventListener('click', () => {
  document.getElementById('category-filter').value = 'all';
  document.getElementById('time-filter').value = 'all';
  document.getElementById('difficulty-filter').value = 'all';
  renderTechniques();
});

document.addEventListener('DOMContentLoaded', renderTechniques);