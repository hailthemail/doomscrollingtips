// tracker.js

let trackerData = JSON.parse(localStorage.getItem('trackerData')) || [];
let screenTimeChart, sleepChart;

function saveData() {
  localStorage.setItem('trackerData', JSON.stringify(trackerData));
}

function updateStats() {
  const totalDays = trackerData.length;
  const avgTime = totalDays > 0 ? (trackerData.reduce((s, d) => s + d.screenTime, 0) / totalDays).toFixed(1) : 0;
  const noDoomDays = trackerData.filter(d => !d.doomscrolling).length;
  
  document.getElementById('total-days').textContent = totalDays;
  document.getElementById('avg-screen-time').textContent = `${avgTime} ч`;
  document.getElementById('no-doom-days').textContent = noDoomDays;
}

function renderHistory() {
  const container = document.getElementById('history-list');
  if (trackerData.length === 0) {
    container.innerHTML = '<p style="text-align:center;color:var(--text-light);padding:40px;">Нет записей. Добавь первую!</p>';
    return;
  }
  container.innerHTML = trackerData.slice(-7).reverse().map(d => `
    <div class="history-item">
      <div><strong>📅</strong> ${d.date}</div>
      <div><strong>⏱️</strong> ${d.screenTime} ч</div>
      <div><strong>📱</strong> ${d.checks} раз</div>
      <div><strong>😊</strong> ${d.moodBefore}→${d.moodAfter}</div>
      <div><strong>😴</strong> ${d.sleep}</div>
      <div><strong>${d.doomscrolling ? '🚨' : '✅'}</strong> ${d.doomscrolling ? 'Был' : 'Нет'}</div>
    </div>
  `).join('');
}

function updateCharts() {
  const ctx1 = document.getElementById('screen-time-chart');
  const ctx2 = document.getElementById('sleep-chart');
  
  if (screenTimeChart) screenTimeChart.destroy();
  if (sleepChart) sleepChart.destroy();
  
  if (trackerData.length === 0) return;
  
  const labels = trackerData.slice(-14).map(d => d.date.slice(5));
  
  screenTimeChart = new Chart(ctx1, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'Часы',
        data: trackerData.slice(-14).map(d => d.screenTime),
        borderColor: '#6366f1',
        backgroundColor: 'rgba(99, 102, 241, 0.2)',
        fill: true,
        tension: 0.4
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.1)' } },
        x: { grid: { display: false } }
      }
    }
  });
  
  sleepChart = new Chart(ctx2, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Сон',
        data: trackerData.slice(-14).map(d => d.sleep),
        backgroundColor: '#8b5cf6',
        borderRadius: 8
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, max: 10, grid: { color: 'rgba(255,255,255,0.1)' } },
        x: { grid: { display: false } }
      }
    }
  });
}

document.getElementById('mood-before').addEventListener('input', e => document.getElementById('mood-before-value').textContent = e.target.value);
document.getElementById('mood-after').addEventListener('input', e => document.getElementById('mood-after-value').textContent = e.target.value);
document.getElementById('sleep-quality').addEventListener('input', e => document.getElementById('sleep-quality-value').textContent = e.target.value);

document.getElementById('tracker-form').addEventListener('submit', e => {
  e.preventDefault();
  
  const entry = {
    date: new Date().toISOString().slice(0, 10),
    screenTime: parseFloat(document.getElementById('screen-time').value),
    checks: parseInt(document.getElementById('phone-checks').value),
    moodBefore: parseInt(document.getElementById('mood-before').value),
    moodAfter: parseInt(document.getElementById('mood-after').value),
    sleep: parseInt(document.getElementById('sleep-quality').value),
    doomscrolling: document.getElementById('doomscrolling').checked
  };
  
  trackerData.push(entry);
  saveData();
  updateStats();
  renderHistory();
  updateCharts();
  
  alert('✅ Запись сохранена!');
  e.target.reset();
  document.getElementById('mood-before-value').textContent = '5';
  document.getElementById('mood-after-value').textContent = '5';
  document.getElementById('sleep-quality-value').textContent = '5';
  document.getElementById('mood-before').value = 5;
  document.getElementById('mood-after').value = 5;
  document.getElementById('sleep-quality').value = 5;
});

document.getElementById('export-btn').addEventListener('click', () => {
  if (trackerData.length === 0) { alert('Нет данных для экспорта!'); return; }
  const csv = 'Дата,Время,Проверки,Настроение до,Настроение после,Сон,Думскроллинг\n' +
    trackerData.map(d => `${d.date},${d.screenTime},${d.checks},${d.moodBefore},${d.moodAfter},${d.sleep},${d.doomscrolling}`).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'tracker-export.csv';
  a.click();
});

document.getElementById('clear-btn').addEventListener('click', () => {
  if (!confirm('Удалить все данные?')) return;
  trackerData = [];
  saveData();
  updateStats();
  renderHistory();
  updateCharts();
  alert('Данные удалены!');
});

document.addEventListener('DOMContentLoaded', () => {
  updateStats();
  renderHistory();
  updateCharts();
});