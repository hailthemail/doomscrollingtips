// alternatives.js

const alternativesByMood = {
  bored: [
    { title: '📖 Прочитай книгу', desc: 'Выбери жанр, который давно хотел попробовать' },
    { title: '🎨 Нарисуй что-то', desc: 'Не обязательно уметь — просто процесс' },
    { title: '🎵 Выучи аккорды', desc: 'Гитара, укулеле, пианино' },
    { title: '📝 Начни дневник', desc: 'Запиши мысли, планы, идеи' },
    { title: '🧩 Собери пазл', desc: 'Или кубик Рубика, головоломку' },
    { title: '🍳 Приготовь новое блюдо', desc: 'Найди рецепт и попробуй' }
  ],
  anxious: [
    { title: '🧘 Медитация', desc: '10 минут тишины и дыхания' },
    { title: '📝 Выпиши тревоги', desc: 'На бумаге они кажутся меньше' },
    { title: '🚶 Прогулка', desc: 'Свежий воздух и движение' },
    { title: '🎵 Музыка', desc: 'Любимые треки или спокойные' },
    { title: '🛁 Тёплый душ', desc: 'Вода смывает напряжение' },
    { title: '📞 Позвони другу', desc: 'Просто поболтай' }
  ],
  tired: [
    { title: '😴 Поспи 20 минут', desc: 'Короткий сон восстановит' },
    { title: '🧘 Лёгкая растяжка', desc: '5 минут без напряжения' },
    { title: '🎵 Спокойная музыка', desc: 'Лежи и слушай' },
    { title: '📖 Лёгкое чтение', desc: 'Что-то приятное, не сложное' },
    { title: '☕ Тёплый чай', desc: 'Без кофеина, с мятой' },
    { title: '🛋 Просто полежи', desc: 'Без телефона, в тишине' }
  ],
  lonely: [
    { title: '📞 Позвони близким', desc: 'Родители, друзья, бабушка' },
    { title: '👥 Встреться с кем-то', desc: 'Кофе, прогулка, кино' },
    { title: '🐕 Волонтёрство', desc: 'Приют для животных' },
    { title: '💬 Клуб по интересам', desc: 'Настолки, книги, спорт' },
    { title: '📝 Напиши письмо', desc: 'Другу, которого давно не видел' },
    { title: '🎮 Онлайн-игра с друзьями', desc: 'Вместо скроллинга' }
  ],
  stressed: [
    { title: '🏃 Интенсивная тренировка', desc: 'Выплесни адреналин' },
    { title: '📝 Выпиши всё', desc: 'Потом порви бумагу' },
    { title: '🎵 Громкая музыка', desc: 'Пой, танцуй, кричи' },
    { title: '🥊 Боксёрская груша', desc: 'Или подушка' },
    { title: '🚶 Быстрая прогулка', desc: 'В быстром темпе' },
    { title: '🛁 Контрастный душ', desc: 'Переключает нервную систему' }
  ]
};

function showAlternatives(mood) {
  const container = document.getElementById('alternatives-container');
  const alts = alternativesByMood[mood];
  container.innerHTML = alts.map(a => `<div class="alt-card"><h3>${a.title}</h3><p>${a.desc}</p></div>`).join('');
}

document.querySelectorAll('.mood-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.mood-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    showAlternatives(btn.dataset.mood);
  });
});

document.getElementById('random-btn').addEventListener('click', () => {
  const allAlts = Object.values(alternativesByMood).flat();
  const random = allAlts[Math.floor(Math.random() * allAlts.length)];
  const result = document.getElementById('random-result');
  result.innerHTML = `<h3>${random.title}</h3><p>${random.desc}</p>`;
  result.classList.add('show');
});

document.addEventListener('DOMContentLoaded', () => {
  showAlternatives('bored');
});